(function($){
	
	"use strict";
	jQuery(document).ready(function($){
		
		$(video-play-btn).magnificPopup({
			
			type:'video',
			
		});
		
		
		
	});
	
	
	jQuery(document).load(function(){
		
		
		
	});
	
	
}(jQuery));